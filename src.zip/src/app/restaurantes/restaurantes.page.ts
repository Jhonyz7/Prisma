import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-restaurantes',
  templateUrl: './restaurantes.page.html',
  styleUrls: ['./restaurantes.page.scss'],
})
export class RestaurantesPage implements OnInit {
  cards = [
    { title: 'Pessoa 1', content: 'Feioso 1' },
    { title: 'Pessoa 2', content: 'Feioso 2' },
  ];

  loadMoreCards(event: any) {
    setTimeout(() => {
      for (let i = 1; i <= 1; i++) {
        this.cards.push({
          title: `Pessoa${this.cards.length + 1}`,
          content: `Feioso ${this.cards.length + 1}`
        });
      }
      event.target.complete();
    }, 1000);
  }

  constructor() { }

  ngOnInit() {
  }

}
